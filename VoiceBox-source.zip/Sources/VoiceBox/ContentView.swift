import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var store: VoiceStore
    @State private var trackingPress = false
    @State private var didCancel = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                if store.messages.isEmpty {
                    Spacer()
                    Image(systemName: "waveform")
                        .font(.system(size: 48, weight: .light))
                        .foregroundStyle(.secondary)
                    Text("还没有语音消息")
                        .font(.headline)
                        .padding(.top, 10)
                    Text("按住底部按钮，录制第一条语音")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .padding(.top, 4)
                    Spacer()
                } else {
                    ScrollViewReader { proxy in
                        ScrollView {
                            LazyVStack(spacing: 14) {
                                ForEach(store.messages) { message in
                                    MessageBubble(message: message)
                                        .id(message.id)
                                        .environmentObject(store)
                                }
                            }
                            .padding(.horizontal, 14)
                            .padding(.vertical, 18)
                        }
                        .onChange(of: store.messages.count) { _ in
                            if let last = store.messages.last {
                                withAnimation { proxy.scrollTo(last.id, anchor: .bottom) }
                            }
                        }
                    }
                }

                Divider()
                recordingPanel
            }
            .navigationTitle("VoiceBox")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Button("清空全部语音", role: .destructive) {
                            for item in store.messages { store.deleteMessage(item) }
                        }
                    } label: {
                        Image(systemName: "ellipsis.circle")
                    }
                }
            }
        }
    }

    private var recordingPanel: some View {
        VStack(spacing: 10) {
            if store.isRecording {
                HStack(spacing: 3) {
                    ForEach(Array(store.liveWaveform.enumerated()), id: \.offset) { _, value in
                        Capsule()
                            .fill(store.isCancelling ? Color.red : Color.green)
                            .frame(width: 3, height: max(4, value * 34))
                    }
                }
                .frame(height: 38)
                .frame(maxWidth: .infinity)
            }

            Text(store.statusText)
                .font(.caption)
                .foregroundStyle(store.isCancelling ? .red : .secondary)

            Text(store.isRecording ? "正在录音  \(store.formattedDuration(store.recordingElapsed))" : "按住说话")
                .font(.system(size: 17, weight: .semibold))
                .foregroundStyle(.primary)
                .frame(maxWidth: .infinity)
                .frame(height: 54)
                .background(store.isCancelling ? Color.red.opacity(0.15) : Color.green.opacity(0.16))
                .clipShape(RoundedRectangle(cornerRadius: 14))
                .overlay {
                    RoundedRectangle(cornerRadius: 14)
                        .stroke(store.isRecording ? (store.isCancelling ? Color.red : Color.green) : Color.green.opacity(0.35), lineWidth: 1)
                }
                .contentShape(Rectangle())
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged { value in
                            if !trackingPress {
                                trackingPress = true
                                didCancel = false
                                store.beginRecording()
                            }
                            let shouldCancel = value.translation.height < -75
                            if shouldCancel != didCancel {
                                didCancel = shouldCancel
                                store.setCancelling(shouldCancel)
                            }
                        }
                        .onEnded { _ in
                            trackingPress = false
                            store.finishRecording(send: !didCancel)
                            didCancel = false
                        }
                )
                .accessibilityLabel("按住说话，松开发送，上滑取消")

            Text("松开发送 · 向上滑动取消")
                .font(.caption2)
                .foregroundStyle(.tertiary)
        }
        .padding(.horizontal, 16)
        .padding(.top, 12)
        .padding(.bottom, 12)
        .background(.regularMaterial)
    }
}

private struct MessageBubble: View {
    @EnvironmentObject private var store: VoiceStore
    let message: VoiceMessage
    @State private var showTranscript = true

    private var isPlaying: Bool { store.playingID == message.id }

    var body: some View {
        HStack {
            Spacer(minLength: 42)
            VStack(alignment: .leading, spacing: 10) {
                HStack(spacing: 10) {
                    Button {
                        store.togglePlayback(message)
                    } label: {
                        Image(systemName: isPlaying ? "pause.fill" : "play.fill")
                            .font(.system(size: 19, weight: .semibold))
                            .foregroundStyle(Color.green)
                            .frame(width: 28, height: 34)
                    }
                    .buttonStyle(.plain)

                    HStack(spacing: 2) {
                        ForEach(Array(message.waveform.enumerated()), id: \.offset) { index, value in
                            Capsule()
                                .fill(Double(index) / Double(max(1, message.waveform.count)) <= store.playbackProgress && isPlaying ? Color.green : Color.primary.opacity(0.48))
                                .frame(width: 3, height: max(5, value * 32))
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 36)

                    Text(store.formattedDuration(message.duration))
                        .font(.system(size: 13, weight: .medium, design: .rounded))
                        .monospacedDigit()
                }

                if !message.transcript.isEmpty {
                    Divider().opacity(0.5)
                    VStack(alignment: .leading, spacing: 5) {
                        Button {
                            withAnimation { showTranscript.toggle() }
                        } label: {
                            HStack {
                                Text("语音转文字")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                Spacer()
                                Image(systemName: showTranscript ? "chevron.up" : "chevron.down")
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        .buttonStyle(.plain)
                        if showTranscript {
                            Text(message.transcript)
                                .font(.system(size: 14))
                                .textSelection(.enabled)
                                .foregroundStyle(.primary)
                        }
                    }
                } else {
                    Text("语音识别处理中…")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Text(message.createdAt.formatted(date: .omitted, time: .shortened))
                    .font(.caption2)
                    .foregroundStyle(.tertiary)
                    .frame(maxWidth: .infinity, alignment: .trailing)
            }
            .padding(12)
            .background(Color.green.opacity(0.13))
            .clipShape(RoundedRectangle(cornerRadius: 15))
            .contextMenu {
                Button(role: .destructive) {
                    store.deleteMessage(message)
                } label: {
                    Label("删除语音", systemImage: "trash")
                }
            }
        }
    }
}

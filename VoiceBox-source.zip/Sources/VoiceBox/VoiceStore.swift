import Foundation
import AVFoundation
import Speech
import SwiftUI

@MainActor
final class VoiceStore: NSObject, ObservableObject, AVAudioPlayerDelegate {
    @Published var messages: [VoiceMessage] = []
    @Published var isRecording = false
    @Published var isCancelling = false
    @Published var recordingElapsed: Double = 0
    @Published var liveWaveform: [Double] = Array(repeating: 0.08, count: 42)
    @Published var playingID: UUID?
    @Published var playbackProgress: Double = 0
    @Published var statusText = "按住下方按钮开始录音"

    private var recorder: AVAudioRecorder?
    private var wantsRecording = false
    private var recordingURL: URL?
    private var recordingStartedAt: Date?
    private var meterTimer: Timer?
    private var player: AVAudioPlayer?
    private var playbackTimer: Timer?
    private let folderName = "VoiceBox"

    override init() {
        super.init()
        loadMessages()
    }

    private var folderURL: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return docs.appendingPathComponent(folderName, isDirectory: true)
    }

    private var metadataURL: URL {
        folderURL.appendingPathComponent("messages.json")
    }

    private func ensureFolder() throws {
        try FileManager.default.createDirectory(at: folderURL, withIntermediateDirectories: true)
    }

    func loadMessages() {
        do {
            try ensureFolder()
            let data = try Data(contentsOf: metadataURL)
            messages = try JSONDecoder().decode([VoiceMessage].self, from: data)
                .filter { FileManager.default.fileExists(atPath: folderURL.appendingPathComponent($0.filename).path) }
                .sorted { $0.createdAt < $1.createdAt }
        } catch {
            messages = []
        }
    }

    private func persist() {
        do {
            try ensureFolder()
            let data = try JSONEncoder().encode(messages)
            try data.write(to: metadataURL, options: .atomic)
        } catch {
            statusText = "保存失败：\(error.localizedDescription)"
        }
    }

    func beginRecording() {
        guard !isRecording, !wantsRecording else { return }
        wantsRecording = true
        statusText = "正在申请麦克风权限…"
        AVAudioSession.sharedInstance().requestRecordPermission { [weak self] granted in
            DispatchQueue.main.async {
                guard let self else { return }
                // 用户可能在系统权限弹窗出现时已经松开手指。
                guard self.wantsRecording else { return }
                guard granted else {
                    self.wantsRecording = false
                    self.statusText = "请在系统设置中允许麦克风权限"
                    return
                }
                self.startRecorder()
            }
        }
    }

    private func startRecorder() {
        do {
            try ensureFolder()
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playAndRecord, mode: .default, options: [.defaultToSpeaker, .allowBluetooth])
            try session.setActive(true)

            let url = folderURL.appendingPathComponent("voice-\(UUID().uuidString).m4a")
            let settings: [String: Any] = [
                AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
                AVSampleRateKey: 44100,
                AVNumberOfChannelsKey: 1,
                AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
            ]
            let newRecorder = try AVAudioRecorder(url: url, settings: settings)
            newRecorder.isMeteringEnabled = true
            guard newRecorder.record() else {
                statusText = "录音启动失败"
                return
            }

            recorder = newRecorder
            recordingURL = url
            recordingStartedAt = Date()
            recordingElapsed = 0
            liveWaveform = []
            isCancelling = false
            isRecording = true
            statusText = "正在录音 · 松开发送，上滑取消"

            meterTimer?.invalidate()
            meterTimer = Timer.scheduledTimer(withTimeInterval: 0.08, repeats: true) { [weak self] _ in
                Task { @MainActor in self?.sampleMeter() }
            }
        } catch {
            statusText = "无法开始录音：\(error.localizedDescription)"
        }
    }

    private func sampleMeter() {
        guard let recorder, recorder.isRecording else { return }
        recorder.updateMeters()
        let db = Double(recorder.averagePower(forChannel: 0))
        let normalized = max(0.06, min(1.0, pow(10.0, db / 35.0)))
        liveWaveform.append(normalized)
        if liveWaveform.count > 42 { liveWaveform.removeFirst() }
        if let start = recordingStartedAt {
            recordingElapsed = Date().timeIntervalSince(start)
        }
    }

    func setCancelling(_ value: Bool) {
        isCancelling = value
        statusText = value ? "松开取消录音" : "正在录音 · 松开发送，上滑取消"
    }

    func finishRecording(send: Bool) {
        wantsRecording = false
        guard isRecording else { return }
        meterTimer?.invalidate()
        meterTimer = nil
        recorder?.stop()
        let elapsed = recordingStartedAt.map { Date().timeIntervalSince($0) } ?? recordingElapsed
        let url = recordingURL
        let peaks = liveWaveform
        recorder = nil
        recordingURL = nil
        recordingStartedAt = nil
        isRecording = false
        isCancelling = false
        recordingElapsed = 0

        guard send, elapsed >= 0.35, let url else {
            if let url { try? FileManager.default.removeItem(at: url) }
            statusText = "已取消"
            liveWaveform = Array(repeating: 0.08, count: 42)
            return
        }

        let filename = url.lastPathComponent
        let message = VoiceMessage(filename: filename, duration: elapsed,
                                   transcript: "", waveform: normalizedPeaks(peaks, count: 48))
        messages.append(message)
        persist()
        statusText = "语音已保存，正在识别…"
        transcribe(url: url, messageID: message.id)
    }

    private func normalizedPeaks(_ values: [Double], count: Int) -> [Double] {
        guard !values.isEmpty else { return Array(repeating: 0.12, count: count) }
        return (0..<count).map { index in
            let sourceIndex = min(values.count - 1, index * values.count / count)
            return max(0.08, min(1.0, values[sourceIndex]))
        }
    }

    private func transcribe(url: URL, messageID: UUID) {
        SFSpeechRecognizer.requestAuthorization { [weak self] auth in
            guard auth == .authorized else {
                Task { @MainActor in self?.setTranscript("未获得语音识别权限", for: messageID) }
                return
            }
            guard let recognizer = SFSpeechRecognizer(locale: Locale(identifier: "zh-CN")),
                  recognizer.isAvailable else {
                Task { @MainActor in self?.setTranscript("当前设备暂时无法使用中文语音识别", for: messageID) }
                return
            }

            let request = SFSpeechURLRecognitionRequest(url: url)
            request.shouldReportPartialResults = false
            if recognizer.supportsOnDeviceRecognition {
                request.requiresOnDeviceRecognition = true
            }

            recognizer.recognitionTask(with: request) { [weak self] result, error in
                if let result, result.isFinal {
                    let text = result.bestTranscription.formattedString
                    Task { @MainActor in self?.setTranscript(text, for: messageID) }
                } else if let error {
                    Task { @MainActor in self?.setTranscript("识别失败：\(error.localizedDescription)", for: messageID) }
                }
            }
        }
    }

    private func setTranscript(_ text: String, for id: UUID) {
        guard let index = messages.firstIndex(where: { $0.id == id }) else { return }
        messages[index].transcript = text
        persist()
        statusText = "语音已保存"
    }

    func togglePlayback(_ message: VoiceMessage) {
        if playingID == message.id {
            player?.pause()
            playbackTimer?.invalidate()
            playingID = nil
            playbackProgress = 0
            return
        }
        stopPlayback()
        do {
            let url = folderURL.appendingPathComponent(message.filename)
            let newPlayer = try AVAudioPlayer(contentsOf: url)
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            newPlayer.delegate = self
            newPlayer.prepareToPlay()
            newPlayer.play()
            player = newPlayer
            playingID = message.id
            playbackProgress = 0
            playbackTimer = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { [weak self] _ in
                Task { @MainActor in
                    guard let self, let player = self.player else { return }
                    self.playbackProgress = player.duration > 0 ? player.currentTime / player.duration : 0
                }
            }
        } catch {
            statusText = "播放失败：\(error.localizedDescription)"
        }
    }

    private func stopPlayback() {
        player?.stop()
        player = nil
        playbackTimer?.invalidate()
        playbackTimer = nil
        playingID = nil
        playbackProgress = 0
    }

    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        stopPlayback()
    }

    func deleteMessage(_ message: VoiceMessage) {
        if playingID == message.id { stopPlayback() }
        try? FileManager.default.removeItem(at: folderURL.appendingPathComponent(message.filename))
        messages.removeAll { $0.id == message.id }
        persist()
    }

    func formattedDuration(_ seconds: Double) -> String {
        let value = max(0, Int(seconds.rounded()))
        return String(format: "%d:%02d", value / 60, value % 60)
    }
}

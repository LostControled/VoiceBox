# VoiceBox

一个本地运行的 iOS 语音消息应用，最低支持 iOS 16。

## 功能
- 按住录音，松开发送，上滑取消
- AAC / M4A 本地音频保存
- 录音波形采样、消息波形显示
- 播放、暂停、播放进度
- Apple Speech 中文语音识别
- 本地 JSON 元数据保存
- 长按消息删除

## 构建
项目使用 XcodeGen。运行：
```bash
brew install xcodegen
xcodegen generate
xcodebuild -project VoiceBox.xcodeproj -scheme VoiceBox -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' CODE_SIGNING_ALLOWED=NO build
```

GitHub Actions 工作流会生成未签名 IPA。该包适合在支持安装未签名应用的 TrollStore 环境中测试，不是 App Store 发布包。

## 权限
首次录音时需要麦克风权限；首次识别时需要语音识别权限。中文识别是否能完全离线取决于设备和系统语言模型支持情况。

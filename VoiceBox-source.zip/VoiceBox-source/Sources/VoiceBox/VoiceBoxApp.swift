import SwiftUI

@main
struct VoiceBoxApp: App {
    @StateObject private var store = VoiceStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .preferredColorScheme(.light)
        }
    }
}


import Foundation
import AVFoundation
import Speech
import SwiftUI

@MainActor
final class VoiceStore: NSObject, ObservableObject, AVAudioPlayerDelegate {
    @Published var messages: [VoiceMessage] = []
    @Published var isRecording = false
    @Published var isCancelling = false
    @Published var recordingElapsed: Double = 0
    @Published var liveWaveform: [Double] = Array(repeating: 0.08, count: 42)
    @Published var playingID: UUID?
    @Published var playbackProgress: Double = 0
    @Published var statusText = "按住下方按钮开始录音"

    private var recorder: AVAudioRecorder?
    private var wantsRecording = false
    private var recordingURL: URL?
    private var recordingStartedAt: Date?
    private var meterTimer: Timer?
    private var player: AVAudioPlayer?
    private var playbackTimer: Timer?
    private let folderName = "VoiceBox"

    override init() {
        super.init()
        loadMessages()
        log("应用启动，VoiceStore 初始化完成")
        log("iOS: \(UIDevice.current.systemVersion)")
        log("麦克风权限说明: \(Bundle.main.object(forInfoDictionaryKey: "NSMicrophoneUsageDescription") ?? "缺失")")
        log("语音识别权限说明: \(Bundle.main.object(forInfoDictionaryKey: "NSSpeechRecognitionUsageDescription") ?? "缺失")")
    }

    private var folderURL: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return docs.appendingPathComponent(folderName, isDirectory: true)
    }

    private var metadataURL: URL {
        folderURL.appendingPathComponent("messages.json")
    }

    private var logURL: URL {
        folderURL.appendingPathComponent("diagnostics.log")
    }

    // MARK: - 诊断日志

    private func log(_ message: String) {
        let timestamp = ISO8601DateFormatter().string(from: Date())
        let line = "[\(timestamp)] \(message)\n"

        do {
            try ensureFolder()
            let data = Data(line.utf8)

            if FileManager.default.fileExists(atPath: logURL.path) {
                let handle = try FileHandle(forWritingTo: logURL)
                try handle.seekToEnd()
                try handle.write(contentsOf: data)
                try handle.close()
            } else {
                try data.write(to: logURL, options: .atomic)
            }
        } catch {
            print("VoiceBox 日志写入失败: \(error)")
        }

        print("[VoiceBox] \(line)", terminator: "")
    }

    // 后续用于导出日志
    func diagnosticLogURL() -> URL {
        log("用户请求导出诊断日志")
        return logURL
    }

    // MARK: - 文件管理

    private func ensureFolder() throws {
        try FileManager.default.createDirectory(
            at: folderURL,
            withIntermediateDirectories: true
        )
    }

    func loadMessages() {
        do {
            try ensureFolder()
            let data = try Data(contentsOf: metadataURL)
            messages = try JSONDecoder().decode([VoiceMessage].self, from: data)
                .filter {
                    FileManager.default.fileExists(
                        atPath: folderURL.appendingPathComponent($0.filename).path
                    )
                }
                .sorted { $0.createdAt < $1.createdAt }

            log("历史消息加载成功，数量: \(messages.count)")
        } catch {
            messages = []
            log("历史消息加载失败或不存在: \(error)")
        }
    }

    private func persist() {
        do {
            try ensureFolder()
            let data = try JSONEncoder().encode(messages)
            try data.write(to: metadataURL, options: .atomic)
        } catch {
            statusText = "保存失败：\(error.localizedDescription)"
            log("消息保存失败: \(error)")
        }
    }

    // MARK: - 录音

    func beginRecording() {
        log("beginRecording 被调用")
        log("当前状态: isRecording=\(isRecording), wantsRecording=\(wantsRecording)")

        guard !isRecording, !wantsRecording else {
            log("跳过录音请求：当前已有录音请求")
            return
        }

        // 检查麦克风权限说明，避免缺少用途说明时触发系统终止
        guard let usage = Bundle.main.object(
            forInfoDictionaryKey: "NSMicrophoneUsageDescription"
        ) as? String, !usage.isEmpty else {
            log("错误：Info.plist 缺少 NSMicrophoneUsageDescription")
            statusText = "缺少麦克风权限说明，请检查应用配置"
            return
        }

        wantsRecording = true
        statusText = "正在申请麦克风权限…"
        log("准备请求麦克风权限")

        let session = AVAudioSession.sharedInstance()
        log("AVAudioSession 实例获取成功")

        session.requestRecordPermission { [weak self] granted in
            DispatchQueue.main.async {
                guard let self else { return }

                self.log("麦克风权限回调，granted=\(granted)")
                self.log("当前 wantsRecording=\(self.wantsRecording)")

                guard self.wantsRecording else {
                    self.log("用户已松开按钮，取消待启动的录音")
                    return
                }

                guard granted else {
                    self.wantsRecording = false
                    self.statusText = "请在系统设置中允许麦克风权限"
                    self.log("麦克风权限被拒绝")
                    return
                }

                self.log("麦克风权限已获得，准备启动录音")
                self.startRecorder()
            }
        }

        log("麦克风权限请求已提交")
    }

    private func startRecorder() {
        log("startRecorder 开始")

        do {
            try ensureFolder()
            log("录音文件夹检查成功")

            let session = AVAudioSession.sharedInstance()

            log("准备设置 AVAudioSession category")
            try session.setCategory(
                .playAndRecord,
                mode: .default,
                options: [.defaultToSpeaker, .allowBluetooth]
            )
            log("AVAudioSession category 设置成功")

            log("准备激活 AVAudioSession")
            try session.setActive(true)
            log("AVAudioSession 激活成功")

            let url = folderURL.appendingPathComponent(
                "voice-\(UUID().uuidString).m4a"
            )

            let settings: [String: Any] = [
                AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
                AVSampleRateKey: 44100,
                AVNumberOfChannelsKey: 1,
                AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
            ]

            log("准备创建 AVAudioRecorder")
            let newRecorder = try AVAudioRecorder(url: url, settings: settings)
            log("AVAudioRecorder 创建成功")

            newRecorder.isMeteringEnabled = true
            log("准备调用 recorder.record()")

            guard newRecorder.record() else {
                log("错误：recorder.record() 返回 false")
                wantsRecording = false
                statusText = "录音启动失败"
                return
            }

            log("recorder.record() 成功")

            recorder = newRecorder
            recordingURL = url
            recordingStartedAt = Date()
            recordingElapsed = 0
            liveWaveform = []
            isCancelling = false
            isRecording = true
            wantsRecording = false
            statusText = "正在录音 · 松开发送，上滑取消"

            meterTimer?.invalidate()
            meterTimer = Timer.scheduledTimer(
                withTimeInterval: 0.08,
                repeats: true
            ) { [weak self] _ in
                Task { @MainActor in
                    self?.sampleMeter()
                }
            }

            log("录音启动流程全部完成")

        } catch {
            wantsRecording = false
            statusText = "无法开始录音：\(error.localizedDescription)"
            log("录音启动异常: \(error)")
            log("错误详情: \(error.localizedDescription)")
        }
    }

    private func sampleMeter() {
        guard let recorder, recorder.isRecording else { return }

        recorder.updateMeters()
        let db = Double(recorder.averagePower(forChannel: 0))
        let normalized = max(0.06, min(1.0, pow(10.0, db / 35.0)))

        liveWaveform.append(normalized)
        if liveWaveform.count > 42 {
            liveWaveform.removeFirst()
        }

        if let start = recordingStartedAt {
            recordingElapsed = Date().timeIntervalSince(start)
        }
    }

    func setCancelling(_ value: Bool) {
        isCancelling = value
        statusText = value
            ? "松开取消录音"
            : "正在录音 · 松开发送，上滑取消"
    }

    func finishRecording(send: Bool) {
        log("finishRecording 被调用，send=\(send)")
        wantsRecording = false

        guard isRecording else {
            log("当前没有正在录制的音频")
            return
        }

        meterTimer?.invalidate()
        meterTimer = nil

        recorder?.stop()

        let elapsed = recordingStartedAt.map {
            Date().timeIntervalSince($0)
        } ?? recordingElapsed

        let url = recordingURL
        let peaks = liveWaveform

        recorder = nil
        recordingURL = nil
        recordingStartedAt = nil
        isRecording = false
        isCancelling = false
        recordingElapsed = 0

        guard send, elapsed >= 0.35, let url else {
            if let url {
                try? FileManager.default.removeItem(at: url)
            }

            statusText = "已取消"
            liveWaveform = Array(repeating: 0.08, count: 42)
            log("录音已取消或时长不足")
            return
        }

        let filename = url.lastPathComponent

        let message = VoiceMessage(
            filename: filename,
            duration: elapsed,
            transcript: "",
            waveform: normalizedPeaks(peaks, count: 48)
        )

        messages.append(message)
        persist()

        statusText = "语音已保存，正在识别…"
        log("语音保存成功，时长: \(elapsed)，文件: \(filename)")

        transcribe(url: url, messageID: message.id)
    }

    private func normalizedPeaks(
        _ values: [Double],
        count: Int
    ) -> [Double] {
        guard !values.isEmpty else {
            return Array(repeating: 0.12, count: count)
        }

        return (0..<count).map { index in
            let sourceIndex = min(
                values.count - 1,
                index * values.count / count
            )
            return max(0.08, min(1.0, values[sourceIndex]))
        }
    }

    // MARK: - 语音识别

    private func transcribe(url: URL, messageID: UUID) {
        log("开始申请语音识别权限")

        SFSpeechRecognizer.requestAuthorization { [weak self] auth in
            Task { @MainActor in
                guard let self else { return }

                self.log("语音识别权限状态: \(auth.rawValue)")

                guard auth == .authorized else {
                    self.setTranscript("未获得语音识别权限", for: messageID)
                    return
                }

                guard let recognizer = SFSpeechRecognizer(
                    locale: Locale(identifier: "zh-CN")
                ), recognizer.isAvailable else {
                    self.setTranscript(
                        "当前设备暂时无法使用中文语音识别",
                        for: messageID
                    )
                    return
                }

                let request = SFSpeechURLRecognitionRequest(url: url)
                request.shouldReportPartialResults = false

                if recognizer.supportsOnDeviceRecognition {
                    request.requiresOnDeviceRecognition = true
                }

                recognizer.recognitionTask(with: request) {
                    [weak self] result, error in

                    if let result, result.isFinal {
                        let text = result.bestTranscription.formattedString

                        Task { @MainActor in
                            self?.log("语音识别完成")
                            self?.setTranscript(text, for: messageID)
                        }
                    } else if let error {
                        Task { @MainActor in
                            self?.log("语音识别失败: \(error)")
                            self?.setTranscript(
                                "识别失败：\(error.localizedDescription)",
                                for: messageID
                            )
                        }
                    }
                }
            }
        }
    }

    private func setTranscript(_ text: String, for id: UUID) {
        guard let index = messages.firstIndex(where: {
            $0.id == id
        }) else { return }

        messages[index].transcript = text
        persist()
        statusText = "语音已保存"
    }

    // MARK: - 播放

    func togglePlayback(_ message: VoiceMessage) {
        log("播放按钮被点击")

        if playingID == message.id {
            player?.pause()
            playbackTimer?.invalidate()
            playingID = nil
            playbackProgress = 0
            return
        }

        stopPlayback()

        do {
            let url = folderURL.appendingPathComponent(message.filename)
            let newPlayer = try AVAudioPlayer(contentsOf: url)

            try AVAudioSession.sharedInstance().setCategory(
                .playback,
                mode: .default
            )

            try AVAudioSession.sharedInstance().setActive(true)

            newPlayer.delegate = self
            newPlayer.prepareToPlay()
            newPlayer.play()

            player = newPlayer
            playingID = message.id
            playbackProgress = 0

            playbackTimer = Timer.scheduledTimer(
                withTimeInterval: 0.05,
                repeats: true
            ) { [weak self] _ in
                Task { @MainActor in
                    guard let self, let player = self.player else {
                        return
                    }

                    self.playbackProgress = player.duration > 0
                        ? player.currentTime / player.duration
                        : 0
                }
            }

        } catch {
            statusText = "播放失败：\(error.localizedDescription)"
            log("播放失败: \(error)")
        }
    }

    private func stopPlayback() {
        player?.stop()
        player = nil
        playbackTimer?.invalidate()
        playbackTimer = nil
        playingID = nil
        playbackProgress = 0
    }

    func audioPlayerDidFinishPlaying(
        _ player: AVAudioPlayer,
        successfully flag: Bool
    ) {
        log("播放结束，successfully=\(flag)")
        stopPlayback()
    }

    // MARK: - 删除与格式化

    func deleteMessage(_ message: VoiceMessage) {
        if playingID == message.id {
            stopPlayback()
        }

        try? FileManager.default.removeItem(
            at: folderURL.appendingPathComponent(message.filename)
        )

        messages.removeAll { $0.id == message.id }
        persist()
        log("删除语音消息: \(message.filename)")
    }

    func formattedDuration(_ seconds: Double) -> String {
        let value = max(0, Int(seconds.rounded()))
        return String(format: "%d:%02d", value / 60, value % 60)
    }
}

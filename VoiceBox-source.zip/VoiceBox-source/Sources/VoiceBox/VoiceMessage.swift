import Foundation

struct VoiceMessage: Identifiable, Codable, Equatable {
    var id: UUID
    var filename: String
    var duration: Double
    var createdAt: Date
    var transcript: String
    var waveform: [Double]

    init(id: UUID = UUID(), filename: String, duration: Double,
         createdAt: Date = Date(), transcript: String = "", waveform: [Double]) {
        self.id = id
        self.filename = filename
        self.duration = duration
        self.createdAt = createdAt
        self.transcript = transcript
        self.waveform = waveform
    }
}
